#pragma once

void flicker_toggle(void);
void flicker_keydown(void);
void flicker_keyup(void);
