# Thermal Printer

<!-- FIXME: Describe thermal printers support here. -->

## Thermal Printer Keycodes

|Key        |Description                             |
|-----------|----------------------------------------|
|`PRINT_ON` |Start printing everything the user types|
|`PRINT_OFF`|Stop printing everything the user types |
